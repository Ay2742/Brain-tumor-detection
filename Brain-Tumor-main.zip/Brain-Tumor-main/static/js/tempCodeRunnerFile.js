const ele=document.getElementById("btn-predict")
// const res=document.getElementById("res")
// ele.addEventListener("click",()=>{
//     res.style.display='block';
// })